"""Build the September 7 G.A.T.E.S. senior-engineering status deck."""

from __future__ import annotations

from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "2026-09-07-gates-senior-engineering-brief.pptx"

NAVY = RGBColor(11, 24, 48)
INK = RGBColor(23, 32, 51)
SLATE = RGBColor(79, 94, 117)
MIST = RGBColor(234, 240, 246)
PAPER = RGBColor(247, 249, 252)
WHITE = RGBColor(255, 255, 255)
TEAL = RGBColor(32, 184, 166)
BLUE = RGBColor(48, 105, 214)
AMBER = RGBColor(222, 139, 37)
RED = RGBColor(205, 70, 74)
GREEN = RGBColor(50, 154, 111)
PALE_TEAL = RGBColor(226, 247, 243)
PALE_BLUE = RGBColor(231, 239, 252)
PALE_AMBER = RGBColor(253, 243, 224)
PALE_RED = RGBColor(252, 235, 236)
FONT = "Noto Sans"
MONO = "Noto Sans Mono"

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
blank = prs.slide_layouts[6]


def background(slide, color=PAPER):
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = color


def rect(slide, x, y, w, h, fill, line=None, radius=True):
    kind = MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE
    shape = slide.shapes.add_shape(kind, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill
    if line is None:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = line
        shape.line.width = Pt(1)
    if radius:
        shape.adjustments[0] = 0.05
    return shape


def text(
    slide,
    value,
    x,
    y,
    w,
    h,
    *,
    size=14,
    color=INK,
    bold=False,
    font=FONT,
    align=PP_ALIGN.LEFT,
    valign=MSO_ANCHOR.TOP,
    margin=0,
):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame = box.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.margin_left = Inches(margin)
    frame.margin_right = Inches(margin)
    frame.margin_top = Inches(margin)
    frame.margin_bottom = Inches(margin)
    frame.vertical_anchor = valign
    paragraph = frame.paragraphs[0]
    paragraph.alignment = align
    paragraph.space_after = Pt(0)
    run = paragraph.add_run()
    run.text = value
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    return box


def line(slide, x1, y1, x2, y2, color=MIST, width=1):
    shape = slide.shapes.add_connector(
        MSO_CONNECTOR.STRAIGHT,
        Inches(x1),
        Inches(y1),
        Inches(x2),
        Inches(y2),
    )
    shape.line.color.rgb = color
    shape.line.width = Pt(width)
    return shape


def pill(slide, value, x, y, w, fill, color=WHITE, size=8.5):
    rect(slide, x, y, w, 0.32, fill)
    text(slide, value, x, y + 0.015, w, 0.28, size=size, color=color, bold=True, align=PP_ALIGN.CENTER)


def header(slide, kicker, title, number, dark=False):
    base = WHITE if dark else INK
    rule = RGBColor(43, 61, 91) if dark else MIST
    text(slide, kicker.upper(), 0.8, 0.38, 10.4, 0.25, size=9, color=TEAL, bold=True)
    text(slide, title, 0.8, 0.72, 11.5, 0.62, size=24, color=base, bold=True)
    text(slide, f"{number:02d}", 12.0, 0.4, 0.5, 0.22, size=9, color=SLATE, bold=True, align=PP_ALIGN.RIGHT)
    line(slide, 0.8, 1.43, 12.55, 1.43, rule, 1.2)


def footer(slide, value, dark=False):
    text(slide, value, 0.8, 7.12, 11.75, 0.18, size=7.5, color=RGBColor(139, 153, 174) if dark else SLATE)


def card(slide, x, y, w, h, title_value, body, accent=TEAL, fill=WHITE, title_size=10.5, body_size=11, body_color=INK):
    rect(slide, x, y, w, h, fill, MIST)
    rect(slide, x, y, 0.07, h, accent, radius=False)
    text(slide, title_value.upper(), x + 0.23, y + 0.2, w - 0.45, 0.27, size=title_size, color=accent, bold=True)
    text(slide, body, x + 0.23, y + 0.58, w - 0.45, h - 0.77, size=body_size, color=body_color)


def bullet_list(slide, items, x, y, w, row_h, accent=TEAL, size=10.5, color=INK):
    for index, item in enumerate(items):
        yy = y + index * row_h
        text(slide, "•", x, yy, 0.18, row_h, size=size + 1, color=accent, bold=True)
        text(slide, item, x + 0.22, yy, w - 0.22, row_h, size=size, color=color)


# 1. Cover
slide = prs.slides.add_slide(blank)
background(slide, NAVY)
rect(slide, 0, 0, 0.23, 7.5, TEAL, radius=False)
text(slide, "G.A.T.E.S.  |  SENIOR ENGINEERING BRIEF", 0.85, 0.62, 8.3, 0.28, size=10, color=TEAL, bold=True)
text(slide, "Gate 2 is implemented.\nIt is not finished.", 0.85, 1.35, 7.8, 1.35, size=36, color=WHITE, bold=True)
text(
    slide,
    "Gate 3 numeric and figure binding now exist. Gate 2 loop tests and Gate 3 adapter/scenarios are in progress locally; citations remain open.",
    0.85,
    3.0,
    7.6,
    1.05,
    size=17,
    color=RGBColor(191, 204, 222),
)
pill(slide, "STATUS: 7 SEP 2026", 0.85, 5.48, 1.9, RGBColor(31, 48, 76))
pill(slide, "ACTIVITY: 4 SEP", 2.9, 5.48, 1.7, RGBColor(31, 48, 76))
pill(slide, "NO TEST RERUN", 4.75, 5.48, 1.75, RGBColor(31, 48, 76), TEAL)
rect(slide, 9.15, 1.28, 3.4, 4.82, RGBColor(20, 37, 65), RGBColor(43, 61, 91))
text(slide, "CURRENT READ", 9.48, 1.62, 2.8, 0.25, size=9, color=TEAL, bold=True)
for index, (value, label, color) in enumerate([
    ("10", "commits pushed to main", TEAL),
    ("396", "recorded passing tests", WHITE),
    ("65", "Gate 2 cases", WHITE),
    ("19", "Gate 3 cases", AMBER),
]):
    yy = 2.12 + index * 0.9
    text(slide, value, 9.48, yy, 2.7, 0.38, size=21, color=color, bold=True, font=MONO)
    text(slide, label, 9.48, yy + 0.38, 2.7, 0.28, size=9.5, color=RGBColor(172, 188, 210))
footer(slide, "main at 2a6e8c3, in sync with origin/main | no tests rerun for this report", dark=True)


# 2. Executive read
slide = prs.slides.add_slide(blank)
background(slide)
header(slide, "Executive read", "Two implemented cores, two open loops, one shared registry seam", 2)
cards = [
    (0.8, "SHIPPED", "Ten commits are merged and pushed to origin/main at 2a6e8c3.", TEAL, PALE_TEAL),
    (4.8, "PROVEN", "Recorded evidence: 396 passing tests, 65 Gate 2 cases, 19 Gate 3 cases, and clean diff hygiene.", BLUE, PALE_BLUE),
    (8.8, "NOT PROVEN", "No repair-loop closure, real paper corpus, citation binding, live report adapter, or semantic accuracy result.", RED, PALE_RED),
]
for x, title_value, body, accent, fill in cards:
    card(slide, x, 1.82, 3.75, 1.72, title_value, body, accent, fill, body_size=12)
card(slide, 0.8, 3.82, 5.75, 2.45, "GATE 2", "Designed and implemented in isolation\n\nIntegration: partial\nMeasurement: not started", TEAL, WHITE, body_size=15)
card(slide, 6.8, 3.82, 5.75, 2.45, "GATE 3", "Numeric and figure binding implemented\n\nIntegration: not started\nMeasurement: archived manuscript only", AMBER, WHITE, body_size=15)
rect(slide, 0.8, 6.47, 11.75, 0.48, NAVY)
text(slide, "Current WIP: Gate 2 loop plus tests, and Gate 3 adapter plus scenarios. All remain uncommitted and unverified.", 1.02, 6.57, 11.3, 0.25, size=11.5, color=WHITE, bold=True)
footer(slide, "Evidence and claims are intentionally separated on every slide.")


# 3. Commit and push ledger
slide = prs.slides.add_slide(blank)
background(slide)
header(slide, "Change ledger", "Ten commits merged and pushed to main", 3)
commits = [
    ("40f0c53", "Repository hygiene", "Cache relocation and frozen-package vintage"),
    ("46f25b5", "Working rules", "Duties, invariants, completion rules, exceptions"),
    ("3946f7b", "Semantic tier", "Grounded method and claim checks, WARN/INFO only"),
    ("3ee20ce", "Gate 2 core", "Ranges, relations, source bands, evidence, limitations"),
    ("3887046", "Feedback and adapter", "Gate 2 rendering and gated_review() seam"),
    ("9c1c4db", "Tier matrix", "65 cases across all tier combinations"),
    ("7ea6c91", "Shared prose scanner", "Moved reusable claim scanning into gates/prose.py"),
    ("2928ed7", "Gate 3 core", "Numeric tokens, exact rendering, and figure checks"),
    ("e5cb3fa", "Gate 3 tests", "19 cases, including the archived manuscript"),
    ("2a6e8c3", "Setup budgets", "Cost warning first; one budget per gate"),
]
for index, (sha, title_value, body) in enumerate(commits):
    col = index % 2
    row = index // 2
    x = 0.8 + col * 5.9
    y = 1.68 + row * 0.91
    rect(slide, x, y, 5.65, 0.72, WHITE, MIST)
    pill(slide, sha, x + 0.16, y + 0.2, 1.05, NAVY, TEAL, 7.5)
    text(slide, title_value, x + 1.38, y + 0.11, 3.95, 0.24, size=9.5, bold=True)
    text(slide, body, x + 1.38, y + 0.39, 3.95, 0.21, size=7.8, color=SLATE)
rect(slide, 0.8, 6.35, 7.55, 0.55, PALE_TEAL, TEAL)
text(slide, "PUSHED", 1.02, 6.49, 0.9, 0.2, size=9, color=TEAL, bold=True)
text(slide, "origin/main = 2a6e8c3", 2.0, 6.45, 5.9, 0.26, size=12, color=INK, bold=True, font=MONO)
rect(slide, 8.58, 6.35, 3.97, 0.55, PALE_AMBER, AMBER)
text(slide, "STALE BRANCH", 8.8, 6.49, 1.2, 0.2, size=8, color=AMBER, bold=True)
text(slide, "origin/gate2-gate3 @ 9c1c4db", 10.0, 6.47, 2.2, 0.22, size=8.5, color=INK, bold=True)
footer(slide, "origin/main push recorded 7 Sep 2026 at 02:27 Pacific. Pull request not confirmed.")


# 4. Verification boundary
slide = prs.slides.add_slide(blank)
background(slide, NAVY)
header(slide, "Recorded verification", "What the evidence supports, and what it does not", 4, dark=True)
facts = [
    ("396", "Full suite passed", "recorded at the tip", TEAL),
    ("65", "Gate 2 cases", "all collected cases", BLUE),
    ("19", "Gate 3 cases", "numeric, render, figures", AMBER),
    ("8", "Typed result literals", "archived paper rejected", WHITE),
]
for index, (value, label, note, accent) in enumerate(facts):
    x = 0.8 + index * 2.98
    rect(slide, x, 1.82, 2.75, 1.62, RGBColor(20, 37, 65), RGBColor(43, 61, 91))
    text(slide, value, x + 0.22, 2.06, 2.3, 0.43, size=22, color=accent, bold=True, font=MONO)
    text(slide, label, x + 0.22, 2.54, 2.3, 0.25, size=10.5, color=WHITE, bold=True)
    text(slide, note, x + 0.22, 2.88, 2.3, 0.22, size=8.5, color=RGBColor(167, 184, 207))
card(slide, 0.8, 3.82, 5.7, 2.45, "SUPPORTED CLAIM", "Gate 2's core and report path work. Gate 3 rejects unbound numerals, resolves tokens, verifies exact rendering, and checks figures.", TEAL, RGBColor(20, 37, 65), body_size=13, body_color=WHITE)
card(slide, 6.82, 3.82, 5.73, 2.45, "OUTSIDE THIS EVIDENCE", "No model-free loop closure, live report adapter, real fetched-paper corpus, citation binding, or semantic accuracy result.", AMBER, RGBColor(20, 37, 65), body_size=13, body_color=WHITE)
pill(slide, "NO TESTS RERUN FOR THIS REPORT", 4.55, 6.52, 4.25, RGBColor(43, 61, 91), TEAL, 9)
footer(slide, "Completed verification reused at the user's request. No suite rerun during report generation.", dark=True)


# 5. Maturity model
slide = prs.slides.add_slide(blank)
background(slide)
header(slide, "Maturity model", "Designed -> implemented -> integrated -> measured", 5)
stages = ["DESIGNED", "IMPLEMENTED", "INTEGRATED", "MEASURED"]
for index, stage in enumerate(stages):
    x = 2.95 + index * 2.35
    pill(slide, stage, x, 1.72, 1.85, NAVY if index < 2 else SLATE, WHITE, 8)
for row, (gate, state_index, note, accent) in enumerate([
    ("GATE 1", 3, "Complete baseline and frozen evidence", GREEN),
    ("GATE 2", 1, "Core implemented; integration partial", TEAL),
    ("GATE 3", 1, "Numeric and figure core implemented; integration open", AMBER),
]):
    y = 2.48 + row * 1.25
    text(slide, gate, 0.8, y + 0.14, 1.55, 0.3, size=13, color=accent, bold=True)
    for index in range(4):
        x = 2.95 + index * 2.35
        active = index <= state_index
        rect(slide, x, y, 1.85, 0.62, accent if active else MIST, accent if active else MIST)
        text(slide, "DONE" if active else "OPEN", x, y + 0.16, 1.85, 0.22, size=8.5, color=WHITE if active else SLATE, bold=True, align=PP_ALIGN.CENTER)
        if index < 3:
            line(slide, x + 1.85, y + 0.31, x + 2.35, y + 0.31, MIST, 2)
    text(slide, note, 2.95, y + 0.75, 8.9, 0.26, size=9.5, color=SLATE)
rect(slide, 0.8, 6.45, 11.75, 0.5, PALE_BLUE, BLUE)
text(slide, "Gates 2 and 3 remain unfinished until each report half and model-free loop half are tested.", 1.02, 6.56, 11.3, 0.25, size=11, color=BLUE, bold=True)
footer(slide, "The maturity model prevents 'implemented' from being reported as 'complete.'")


# 6. Gate 2
slide = prs.slides.add_slide(blank)
background(slide)
header(slide, "Gate 2", "Deep interface, unfinished boundary", 6)
tiers = [
    (0.8, "TIER A", "Deterministic", "Ranges and arithmetic relations\nVerdict authority: FAIL", RED, PALE_RED),
    (4.75, "TIER B", "Reference bands", "Intervals and tolerances\nDefault WARN; strict FAIL", AMBER, PALE_AMBER),
    (8.7, "TIER C", "Semantic", "Method and claim alignment\nWARN or INFO only", BLUE, PALE_BLUE),
]
for x, tier, title_value, body, accent, fill in tiers:
    rect(slide, x, 1.78, 3.8, 1.75, fill, accent)
    pill(slide, tier, x + 0.22, 2.0, 0.82, accent, WHITE, 8)
    text(slide, title_value, x + 1.2, 1.98, 2.25, 0.3, size=13, bold=True)
    text(slide, body, x + 0.22, 2.53, 3.3, 0.66, size=10.5, color=SLATE)
card(slide, 0.8, 3.82, 5.72, 2.47, "IMPLEMENTED BEHIND run_gate2()", "Validation, semantic warnings, evidence serialization, declared limitations, feedback rendering, and public exports.", TEAL, WHITE, body_size=13)
card(slide, 6.82, 3.82, 5.73, 2.47, "IN PROGRESS AT THE SEAM", "Five model-free rig scenarios now exist locally. Paper registry, lit_review extraction, integration proof, replicate contract, and measurement remain.", RED, WHITE, body_size=12.5)
rect(slide, 0.8, 6.49, 11.75, 0.46, NAVY)
text(slide, "Boundary rule: external literature is parsed in the adapter; gates/ stays host-free and stdlib-only.", 1.02, 6.59, 11.3, 0.24, size=11, color=WHITE, bold=True)
footer(slide, "Local Gate 2 rig is uncommitted and was not run for this report. External data remains the delivery risk.")


# 7. Gate 3
slide = prs.slides.add_slide(blank)
background(slide, NAVY)
header(slide, "Gate 3", "Numeric and figure binding landed; citation binding is blocked", 7, dark=True)
text(slide, "NUMERIC TRACK", 0.8, 1.75, 3, 0.25, size=10, color=TEAL, bold=True)
numeric = [
    ("Gate 1 registry", TEAL),
    ("\\result{key} parser", BLUE),
    ("exact renderer check", GREEN),
]
for index, (label, accent) in enumerate(numeric):
    x = 0.8 + index * 2.25
    rect(slide, x, 2.18, 1.78, 0.82, RGBColor(20, 37, 65), accent)
    text(slide, label, x + 0.12, 2.39, 1.54, 0.32, size=10, color=WHITE, bold=True, align=PP_ALIGN.CENTER)
    if index < 2:
        text(slide, "→", x + 1.84, 2.34, 0.28, 0.3, size=16, color=RGBColor(167, 184, 207), bold=True, align=PP_ALIGN.CENTER)
text(slide, "CITATION TRACK", 0.8, 3.52, 3, 0.25, size=10, color=AMBER, bold=True)
citation = [
    ("PaperRecord seam", AMBER),
    ("registry citations", BLUE),
    ("generated bib", GREEN),
]
for index, (label, accent) in enumerate(citation):
    x = 0.8 + index * 2.25
    rect(slide, x, 3.95, 1.78, 0.82, RGBColor(20, 37, 65), accent)
    text(slide, label, x + 0.12, 4.16, 1.54, 0.32, size=10, color=WHITE, bold=True, align=PP_ALIGN.CENTER)
    if index < 2:
        text(slide, "→", x + 1.84, 4.11, 0.28, 0.3, size=16, color=RGBColor(167, 184, 207), bold=True, align=PP_ALIGN.CENTER)
card(slide, 7.75, 1.78, 4.8, 2.12, "IMPLEMENTED", "Token resolution, exact registry rendering, numeric-literal scanning, and figure existence checks.", TEAL, RGBColor(20, 37, 65), body_size=13, body_color=WHITE)
card(slide, 7.75, 4.18, 4.8, 2.12, "BLOCKED ON THE SEAM", "Citation binding needs stable fetched-paper identity, metadata, hash, and retrieval provenance.", AMBER, RGBColor(20, 37, 65), body_size=13, body_color=WHITE)
pill(slide, "EXHAUSTION: GateFailure, no manuscript", 4.32, 6.5, 4.7, RGBColor(43, 61, 91), AMBER, 9)
footer(slide, "Archived manuscript result: FAIL, one findings section, eight typed numeric literals.", dark=True)


# 8. Rules I
slide = prs.slides.add_slide(blank)
background(slide)
header(slide, "Research rules 1 of 2", "Duties, invariants, and product completion", 8)
card(slide, 0.8, 1.75, 3.75, 2.0, "DUTIES IN ORDER", "1. No fabricated result passes.\n2. Caught defects return to the agent.\n3. Reports claim only what was checked.", TEAL, WHITE, body_size=11.5)
card(slide, 4.78, 1.75, 3.75, 2.0, "VERDICT AUTHORITY", "Deterministic checks decide. Models are injected and can emit only WARN or INFO.", BLUE, WHITE, body_size=11.5)
card(slide, 8.56, 1.75, 3.99, 2.0, "ABSENCE AND MUTATION", "No input means no check, not green. A gate never edits the artifact it judges.", AMBER, WHITE, body_size=11.5)
card(slide, 0.8, 4.02, 3.75, 2.2, "PACKAGE BOUNDARY", "stdlib-only gates/. No host or rig imports. Host knowledge and lazy imports stay in adapters.", TEAL, WHITE, body_size=11)
card(slide, 4.78, 4.02, 3.75, 2.2, "EVIDENCE", "Two artifacts per gate. Append-only ledger. Frozen signed package stays untouched.", BLUE, WHITE, body_size=11)
card(slide, 8.56, 4.02, 3.99, 2.2, "DEFINITION OF DONE", "Actionable feedback plus model-free rig, one adapter, tested halves, opt-in cost, and a stable install skill.", RED, WHITE, body_size=11)
footer(slide, "Authority: CLAUDE.md at 2a6e8c3, pushed on main.")


# 9. Rules II
slide = prs.slides.add_slide(blank)
background(slide)
header(slide, "Research rules 2 of 2", "Exhaustion, evidence claims, build discipline, and exceptions", 9)
exhaustion = [
    ("GATE 1", "FAIL CLOSED", "Raise GateFailure", RED),
    ("GATE 2", "PROCEED", "Carry limitations", AMBER),
    ("GATE 3", "FAIL CLOSED", "Raise GateFailure", RED),
]
for index, (gate, mode, note, accent) in enumerate(exhaustion):
    x = 0.8 + index * 3.0
    rect(slide, x, 1.75, 2.72, 1.22, WHITE, MIST)
    text(slide, gate, x + 0.18, 1.96, 0.95, 0.24, size=10, color=accent, bold=True)
    text(slide, mode, x + 1.08, 1.96, 1.42, 0.24, size=10, bold=True)
    text(slide, note, x + 0.18, 2.36, 2.3, 0.24, size=9.5, color=SLATE)
rect(slide, 9.82, 1.75, 2.73, 1.22, NAVY)
text(slide, "BUDGET", 10.02, 1.96, 0.82, 0.24, size=10, color=TEAL, bold=True)
text(slide, "Adapter owns state", 10.02, 2.36, 2.2, 0.24, size=9.5, color=WHITE)
card(slide, 0.8, 3.3, 5.72, 2.42, "CLAIM BOUNDARY", "Construction claims require deterministic exclusion. Semantic checks require human labels, confidence intervals, and cost. A lower gate never proves a later gate's property.", TEAL, WHITE, body_size=12)
card(slide, 6.82, 3.3, 5.73, 2.42, "BUILD AND EXCEPTIONS", "Full venv suite for implementation verification. Regression test first. Cache under .cache/. Do not rewrite published identifiers. retrieval.py is not the paper registry.", BLUE, WHITE, body_size=12)
rect(slide, 0.8, 6.05, 11.75, 0.72, PALE_AMBER, AMBER)
text(slide, "Workflow rule: read progress.md first; update it with verified facts, blockers, decisions, and exact next steps.", 1.02, 6.24, 11.3, 0.28, size=11, color=INK, bold=True)
footer(slide, "The detailed report carries the complete rule inventory and documentation exceptions.")


# 10. Next work and decisions
slide = prs.slides.add_slide(blank)
background(slide, NAVY)
header(slide, "Next work", "Sequence by dependency, not by an invented deadline", 10, dark=True)
steps = [
    ("01", "LAND GATE 2 LOOP", "Review and verify five local scenarios", TEAL),
    ("02", "GATE 3 LOOP", "Land adapter/scenarios; add executable rig", BLUE),
    ("03", "PAPER SEAM", "Approve PaperRecord and host extraction", GREEN),
    ("04", "CITATIONS", "Registry identity, metadata, generated bib", AMBER),
    ("05", "PRODUCTIZE", "Measurement, docs, and install skill", RED),
]
for index, (number, title_value, body, accent) in enumerate(steps):
    x = 0.8 + index * 2.35
    rect(slide, x, 1.75, 2.12, 2.15, RGBColor(20, 37, 65), RGBColor(43, 61, 91))
    text(slide, number, x + 0.18, 1.98, 0.5, 0.28, size=12, color=accent, bold=True, font=MONO)
    text(slide, title_value, x + 0.18, 2.44, 1.75, 0.3, size=11, color=WHITE, bold=True)
    text(slide, body, x + 0.18, 2.93, 1.75, 0.72, size=9.5, color=RGBColor(178, 193, 213))
text(slide, "SENIOR ENGINEERING DECISIONS", 0.8, 4.35, 5, 0.25, size=10, color=TEAL, bold=True)
bullet_list(slide, [
    "Delete the merged gate2-gate3 branches, or retain them for audit?",
    "Approve the minimal shared paper-record schema?",
    "Land the current loop and adapter WIP before the paper seam?",
], 0.8, 4.85, 7.1, 0.55, TEAL, 11, WHITE)
rect(slide, 8.35, 4.38, 4.2, 1.92, RGBColor(20, 37, 65), TEAL)
text(slide, "BOTTOM LINE", 8.65, 4.7, 3.6, 0.25, size=9, color=TEAL, bold=True)
text(slide, "Both cores are reviewable.\nNeither gate is complete.", 8.65, 5.12, 3.55, 0.78, size=18, color=WHITE, bold=True)
pill(slide, "REPORT IS EVIDENCE-BOUNDED", 4.55, 6.55, 4.25, RGBColor(43, 61, 91), TEAL, 9)
footer(slide, "G.A.T.E.S. senior engineering brief | 7 Sep 2026", dark=True)


prs.save(OUTPUT)
print(OUTPUT)
