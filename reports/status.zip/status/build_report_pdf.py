"""Render the September 7 G.A.T.E.S. status report as HTML and PDF."""

from __future__ import annotations

from html import escape
from pathlib import Path
import re
import subprocess


HERE = Path(__file__).resolve().parent
MD_PATH = HERE / "2026-09-07-gates-status-report.md"
HTML_PATH = HERE / "2026-09-07-gates-status-report.html"
PDF_PATH = HERE / "2026-09-07-gates-status-report.pdf"


def inline(text: str) -> str:
    rendered = escape(text)
    rendered = re.sub(r"`([^`]+)`", r"<code>\1</code>", rendered)
    rendered = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", rendered)
    return rendered


def markdown_body(text: str) -> str:
    output: list[str] = []
    table_open = False
    list_open: str | None = None

    def close_blocks() -> None:
        nonlocal table_open, list_open
        if table_open:
            output.append("</tbody></table>")
            table_open = False
        if list_open:
            output.append(f"</{list_open}>")
            list_open = None

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            close_blocks()
            continue

        if stripped.startswith("|"):
            if list_open:
                output.append(f"</{list_open}>")
                list_open = None
            cells = [cell.strip() for cell in stripped.strip("|").split("|")]
            if all(re.fullmatch(r":?-+:?", cell) for cell in cells):
                continue
            if not table_open:
                table_open = True
                output.append("<table><thead><tr>")
                output.extend(f"<th>{inline(cell)}</th>" for cell in cells)
                output.append("</tr></thead><tbody>")
            else:
                output.append("<tr>")
                output.extend(f"<td>{inline(cell)}</td>" for cell in cells)
                output.append("</tr>")
            continue

        if table_open:
            output.append("</tbody></table>")
            table_open = False

        match = re.match(r"^(\d+)\.\s+(.*)$", stripped)
        if match:
            if list_open != "ol":
                if list_open:
                    output.append(f"</{list_open}>")
                output.append("<ol>")
                list_open = "ol"
            output.append(f"<li>{inline(match.group(2))}</li>")
            continue
        if stripped.startswith("- "):
            if list_open != "ul":
                if list_open:
                    output.append(f"</{list_open}>")
                output.append("<ul>")
                list_open = "ul"
            output.append(f"<li>{inline(stripped[2:])}</li>")
            continue
        if list_open:
            output.append(f"</{list_open}>")
            list_open = None

        if stripped.startswith("# "):
            output.append(f"<h1>{inline(stripped[2:])}</h1>")
        elif stripped.startswith("## "):
            output.append(f"<h2>{inline(stripped[3:])}</h2>")
        elif stripped.startswith("### "):
            output.append(f"<h3>{inline(stripped[4:])}</h3>")
        else:
            output.append(f"<p>{inline(stripped)}</p>")

    close_blocks()
    return "\n".join(output)


def document(body: str) -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>G.A.T.E.S. engineering status report</title>
<style>
@page {{ size: letter; margin: 0.55in 0.6in; }}
* {{ box-sizing: border-box; }}
body {{ font: 9.2pt/1.38 "Noto Sans", "Liberation Sans", sans-serif; color: #172033; margin: 0; }}
h1 {{ font-size: 22pt; line-height: 1.08; margin: 0 0 10pt; color: #0b1830; border-top: 7pt solid #20b8a6; padding-top: 12pt; }}
h2 {{ font-size: 13pt; margin: 17pt 0 6pt; color: #0b1830; border-bottom: 1px solid #cbd5e1; padding-bottom: 3pt; page-break-after: avoid; }}
h3 {{ font-size: 10.5pt; margin: 10pt 0 4pt; color: #334a70; page-break-after: avoid; }}
p {{ margin: 0 0 6pt; }}
ul, ol {{ margin: 2pt 0 8pt 18pt; padding: 0; }}
li {{ margin: 0 0 3pt; }}
table {{ width: 100%; border-collapse: collapse; margin: 6pt 0 10pt; font-size: 8pt; page-break-inside: avoid; }}
th {{ color: white; background: #17294a; text-align: left; padding: 5pt; border: 1px solid #17294a; }}
td {{ padding: 5pt; vertical-align: top; border: 1px solid #cbd5e1; }}
tr:nth-child(even) td {{ background: #f4f7fa; }}
code {{ font: 8pt "Noto Sans Mono", "Liberation Mono", monospace; background: #eef2f6; padding: 1pt 2pt; }}
strong {{ color: #0b1830; }}
</style>
</head>
<body>{body}</body>
</html>"""


def main() -> None:
    HTML_PATH.write_text(
        document(markdown_body(MD_PATH.read_text(encoding="utf-8"))),
        encoding="utf-8",
    )
    result = subprocess.run(
        [
            "libreoffice",
            "--headless",
            "--convert-to",
            "pdf:writer_pdf_Export",
            str(HTML_PATH),
            "--outdir",
            str(HERE),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode:
        raise SystemExit(result.stderr or result.stdout)
    print(PDF_PATH)


if __name__ == "__main__":
    main()
