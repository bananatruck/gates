# G.A.T.E.S. engineering status report

**Status date:** September 7, 2026  
**Audience:** Senior engineering review  
**Current branch:** `main` at `2a6e8c3`, in sync with `origin/main`  
**Change window:** `e187708..2a6e8c3`  
**Evidence policy:** This report reuses the recorded verification. No tests were rerun during report generation.

## Executive status

Ten commits are now merged and pushed to `main`. The change window adds 3,319 lines and removes 88 across 16 files. Gate 2's three-tier checking engine is implemented. A five-scenario model-free Gate 2 loop and its test module are now in progress in the working tree, but they are uncommitted and unverified. Gate 3 has deterministic numeric and figure binding, feedback rendering, 19 tests, and one measurement against the archived manuscript. A `gated_report()` adapter entry point and five Gate 3 scenario definitions are also in progress but uncommitted. Gate 3 citation binding and the executable Gate 3 loop remain open.

The recorded suite is 396 passing tests. That figure was verified at each of the ten commits according to the project progress record. The report-generation task did not rerun it.

| Signal | Current reading | Meaning |
|---|---:|---|
| Commits merged to `main` | 10 | All are pushed to `origin/main` |
| Diff from prior `origin/main` | 16 files, +3,319 / -88 | Gate 2, Gate 3 numeric binding, shared prose scanner, setup, tests, and rules |
| Recorded full-suite result | 396 passed | Reused evidence, not a new run |
| Gate 2 tests | 65 | Three-tier matrix |
| Gate 3 tests | 19 | Numeric tokens, rendering, figures, feedback, archived manuscript |
| Setup tests | 7 | Cost warning and per-gate retry-budget selection |

## What changed today

Four September 7 commits extended the six September 4 Gate 2 commits.

| Commit | Change | Engineering result |
|---|---|---|
| `7ea6c91` | Moved the prose scanner from `rig/paper_audit.py` to `gates/prose.py` | Gate 3 can reuse manuscript section and claim extraction without importing `rig/` |
| `2928ed7` | Added `gates/gate3.py`, public exports, and feedback support | Implemented four deterministic report-validity checks and result-token rendering |
| `e5cb3fa` | Added `tests/test_gate3.py` | Added 19 tests, including the archived manuscript measurement |
| `2a6e8c3` | Added `gates/setup.py`, seven setup tests, and rule updates | Setup now states cost before asking for one retry budget per gate |

The six earlier commits remain part of the same merged change window:

| Commit | Change |
|---|---|
| `40f0c53` | Moved build output under `.cache/` and documented the frozen-package vintage |
| `46f25b5` | Added the project working rules |
| `3946f7b` | Added Gate 2 semantic checks, fixed at `WARN` or `INFO` |
| `3ee20ce` | Added the Gate 2 core engine |
| `3887046` | Added Gate 2 feedback rendering and `gated_review()` |
| `9c1c4db` | Added 65 Gate 2 tests across the tier matrix |

## What has been pushed

| Ref | Commit | State |
|---|---|---|
| Local `main` | `2a6e8c3` | In sync with `origin/main` |
| `origin/main` | `2a6e8c3` | Contains all ten commits; push recorded September 7 at 02:27 Pacific |
| Local `gate2-gate3` | `2a6e8c3` | Fast-forwarded into `main`; safe to remove after review |
| `origin/gate2-gate3` | `9c1c4db` | Contains the first six commits only |

No pull request was confirmed during this review. The generated status artifacts under `reports/status/` and `progress.md` are untracked and have not been pushed.

### Uncommitted work in progress

| Path | Current content | Verification state |
|---|---|---|
| `rig/gate2_loop.py` | Drives the real `gated_review()` path, ledger, feedback, limitations, budget behavior, and CLI output | Not run or committed during this report task |
| `rig/gate2_scenarios.py` | Five scripted scenarios: range fix, relation repair, out-of-band repair, unresolved discrepancy, and semantic warning | Not run or committed during this report task |
| `tests/test_gate2_loop.py` | Holds Gate 2 loop closure, feedback delivery, exhaustion, limitation carry-forward, ledger, artifacts, and CLI behavior | Not run or committed during this report task |
| `gates/adapters/agentlab.py` | Draft `gated_report()` call site and accepted-manuscript handoff for Gate 3 | Not run or committed during this report task |
| `rig/gate3_scenarios.py` | Five scripted manuscript failure and repair scenarios for numeric literals, missing keys, edited rendering, figures, and exhaustion | No executable Gate 3 loop yet; not run or committed |

These files are plausible next-step implementation, not completed evidence. Their presence moves the loops and adapter from "missing" to "in progress" only.

## Verification evidence reused

No test command was run during report generation. The brief uses the completed verification recorded for the implementation sequence:

- Full suite at the tip: 396 passing tests.
- Gate 2: 65 cases.
- Gate 3: 19 cases.
- Setup: seven cases.
- Diff hygiene: `git diff --check e187708..2a6e8c3` completed without output.
- Earlier Gate 2 strict-reference smoke: expected failures for range, internal consistency, and reference interval; six carried limitations; JSON evidence and actionable feedback.
- Gate 3 archived-manuscript measurement: verdict `FAIL`, one findings section detected, and eight numeric literals typed directly into the archived gated manuscript.

The Gate 3 result is the expected finding. Gate 1 proved that values were real when computed. It did not prove that the same values reached the manuscript through a bound channel.

## Gate maturity

| Gate | Designed | Implemented | Integrated | Measured | Current assessment |
|---|---|---|---|---|---|
| Gate 1 | Yes | Yes | Yes | Yes | Complete baseline; finalized evidence package is frozen |
| Gate 2 | Yes | Yes | Partial | No | Core and adapter exist; rig is in progress and real literature seam remains open |
| Gate 3 | Yes | Partial | In progress | Partial | Numeric and figure binding exist; adapter draft is local; citations and rig remain open |

The repository completion rule is stricter than module implementation. A gate is unfinished until its actionable report and model-free scenario loop both exist and are tested.

## Gate 2 progress

### Implemented

- Tier A deterministic range checks and arithmetic relations.
- Tier B comparisons against caller-supplied source intervals and tolerances.
- Reference discrepancies are `WARN` by default and can be strict `FAIL` by policy.
- Tier C grounded method and claim checks, fixed at `WARN` or `INFO`.
- `run_gate2(registry, config)` public interface.
- JSON evidence, declared limitations, and actionable feedback.
- `gated_review()` Agent Laboratory adapter entry point.
- 65 tests across every tier combination.

### Still open

- A five-scenario `rig/gate2_loop.py` draft and test module now exist, but they are uncommitted and were not run for this report.
- No fetched-paper registry for a real Tier B corpus.
- No stable adapter path from `phd.lit_review` to `SourceClaim` records.
- No live reference-host integration proof.
- No explicit per-seed replicate contract for Gate 1 requirement P5.
- No human-labeled semantic precision, recall, confidence intervals, or model-cost measurement.

### Architecture assessment

`run_gate2()` is a deep module. It hides deterministic validation, source-band comparison, semantic warnings, evidence serialization, feedback, and limitation extraction behind one interface. The remaining delivery risk sits at the external literature boundary. The adapter must convert host output into trusted paper and claim records while `gates/` remains host-free and standard-library-only.

## Gate 3 progress

### Implemented

- `report.no_numeric_literals_in_results`: scans findings sections for digits typed by the writer.
- `report.all_tokens_resolve`: requires every `\result{key}` token to resolve against Gate 1's citable registry.
- `report.rendered_values_match_registry`: checks byte identity between rendered substitutions and registry values.
- `report.figures_referenced_exist`: checks referenced figures on disk and, when configured, inside the accepted run's artifact root.
- `render_result_tokens()`: substitutes `str(value)` without rounding and leaves unknown tokens intact for a precise failure.
- Missing findings coverage degrades to `INFO`; a manuscript with no figure emits no figure check.
- JSON report, rendered manuscript artifact, public exports, and actionable feedback.
- 19 tests, including the archived-manuscript measurement.

### Still open

- No fetched-paper registry.
- No checks for citation identifiers, generated bibliography, or metadata agreement.
- No model-assisted claim-entailment check.
- A `gated_report()` adapter entry point and accepted-manuscript handoff are in progress in the working tree, but are uncommitted and unverified.
- Five Gate 3 scenario definitions exist locally, but no executable `rig/gate3_loop.py` repair loop exists yet.
- No full report-generation integration proof.
- No semantic measurement or model-cost result.

### Honesty boundary

The result-token pipeline can support a construction-level claim only when the writer emits tokens and the renderer performs registry substitution. The numeric-literal scanner enforces use of that pipeline, but it is still a prose scanner and has a false-negative rate. The paper must state the claim as a pipeline property, not as perfect scanner recall.

## Setup progress

`gates/setup.py` now owns the retry-budget prompt. It prints the cost warning first, then accepts one positive integer for each gate. Empty input and end-of-input accept the gate's configured default. The gate modules do not compare their own attempt with the retry budget; the adapter owns attempt state.

This closes the setup-time budget-selection rule at the package level. Host wiring still needs to consume the selected values.

## Research and implementation rules

The authoritative source is `CLAUDE.md`. The complete current rule inventory follows.

### Gate duties, in priority order

1. No fabricated result passes.
2. A caught defect returns through an actionable feedback loop, not to a human gatekeeper.
3. Reports state exactly what was checked and do not extend evidence into a broader claim.

### Structural invariants

1. `gates/` uses only the Python standard library at runtime.
2. Models arrive through an injected `ModelFn`; provider SDKs do not enter the package.
3. Deterministic checks alone decide verdicts. Model checks are fixed at `WARN` or `INFO`.
4. An unconfigured tier emits no check. Absence is not reported as success.
5. A gate reads the judged artifact and writes evidence beside it. It does not mutate the artifact.
6. Each gate writes two artifacts, and the evidence ledger is append-only.
7. `gates/` imports neither the host scaffold nor `rig/`.
8. Host knowledge stays in adapters, and host imports are lazy.

### Product completion rules

1. Every gate ships actionable feedback and a model-free scenario loop. Both halves must be tested.
2. Every gate installs into an existing scaffold through one adapter. Agent Laboratory is the reference host.
3. Model cost is reported through `ModelBudget`, and measurement is opt-in.
4. Retry budgets are chosen during setup after showing cost.
5. Setup owns warning and prompt text; the adapter owns attempt state.
6. A gate never compares its own attempt count with the maximum budget.
7. The install path must ship as a `SKILL.md` that teaches a coding agent to write the adapter, place call sites, and budget in agent turns.

### Exhaustion rules

| Gate | On exhaustion |
|---|---|
| Gate 1 | Raise `GateFailure`. A run that never produced a valid experiment cannot produce a paper. |
| Gate 2 | Continue, but carry every unresolved discrepancy forward as a mandatory declared limitation. |
| Gate 3 | Raise `GateFailure`. An unverifiable manuscript is not emitted. |

### Build and evidence rules

1. Run the complete suite with `.venv/bin/python -m pytest` for implementation verification.
2. Start a bug fix with a failing regression test.
3. Put build and cache output under `.cache/`.
4. Do not commit scratch notes, TODO dumps, or generated summaries unless requested.
5. Treat `reports/finalized-report-and-results/` as a frozen, checksum-signed package.
6. Do not edit frozen metrics to match the current tree; document their vintage instead.

### Research claim boundary

1. A construction-level claim is valid only for a defect excluded by deterministic structure.
2. Semantic model checks are empirical. Report them with human labels, confidence intervals, and cost.
3. Gate 2 reference discrepancies are limitations unless strict policy is explicitly enabled.
4. A passed lower gate does not prove the properties owned by a later gate.
5. Gate 3 numeric elimination is a property of the token-and-render pipeline, not a claim of perfect prose-scanner recall.

### Known exceptions and workflow rules

1. Do not mass-rewrite published em-dash identifiers in `GATE_NAME`; doing so would break correspondence with frozen evidence.
2. Do not treat `gates/retrieval.py` as the missing fetched-paper registry.
3. Read `progress.md` at the start of a session.
4. Update `progress.md` after a task with only verified commits, diffs, tests, decisions, blockers, and exact next steps.

## Plausible next steps

These are dependency-ordered work items, not schedule commitments.

1. Review, run, and commit the in-progress Gate 2 loop and five scenarios to prove reject-fix-accept closure.
2. Review and commit the in-progress `gated_report()` adapter, then add `rig/gate3_loop.py` with Gate 3 exhaustion raising `GateFailure`.
3. Define the minimal shared `PaperRecord` seam with stable ID, source locator, title, authors, year, content hash, and retrieval provenance.
4. Connect Agent Laboratory literature output to that seam, then run Gate 2 Tier B against a real fetched corpus.
5. Implement Gate 3 citation identity, generated bibliography, and metadata checks against the same registry.
6. Add Gate 2's per-seed replicate contract and human-labeled semantic evaluation.
7. Add Gate 3 claim entailment, integration proof, semantic evaluation, and `ModelBudget` measurement.
8. Package the stable adapter and call-site workflow as the required installation `SKILL.md`.
9. Reconcile `README.md`, `docs/PLAN.md`, `docs/GATE1_SUMMARY.md`, and `reports/README.md` with the current implementation and 396-test count.

## Decisions for senior engineering

1. Delete the merged local `gate2-gate3` branch and its stale remote branch, or retain it for audit history.
2. Approve the minimal `PaperRecord` interface before Gate 2 real-corpus wiring and Gate 3 citation work diverge.
3. Confirm that the next completion target is verification and landing of the in-progress Gate 2 loop and Gate 3 adapter, followed by the Gate 3 loop.

## Documentation drift

| Location | Stale statement | Current state |
|---|---|---|
| `README.md` | Gate 2 and Gate 3 are described as designed | Gate 2 is implemented but incomplete; Gate 3 numeric and figure binding are implemented |
| `docs/PLAN.md` build order | Gate 2 and Gate 3 are pending | Both have implementation; both remain incomplete under the product rule |
| `docs/PLAN.md` budget text | Old no-default budget rule | Setup now shows cost and accepts per-gate defaults or overrides |
| `docs/GATE1_SUMMARY.md` | Gates 2 and 3 are not implemented | Both now have code; Gate 3 citation binding remains absent |
| `gates/gate2.py` module text | Semantic tier is not built | Semantic tier exists and is warning-only |
| `reports/README.md` | Current tree reports 321 | Current recorded suite reports 396 |

## Bottom line

The project has crossed an important boundary: Gate 3 now detects that the archived gated manuscript typed eight result numerals directly even though Gate 1 verified the underlying execution. That finding validates the need for a report-validity gate without proving the rest of Gate 3. The immediate work is already visible in the tree: finish and verify the Gate 2 loop and Gate 3 adapter, then add the Gate 3 loop and define one shared fetched-paper seam for Gate 2 real-corpus checks and Gate 3 citation binding.
