import random

random.seed(0)
correct, total = 408, 500
test_acc = correct / total
sgc_wallclock = 0.0180
gcn_wallclock = 0.2450

print(f"Final test accuracy: {test_acc:.4f}")
print(f"SGC {sgc_wallclock:.4f}s   GCN {gcn_wallclock:.4f}s")
print(f"Speedup: {gcn_wallclock / sgc_wallclock:.2f}x")
