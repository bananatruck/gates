record_metadata("seed", 0)

test_acc = 0.4
record_result("exp1.K2.test_acc", 0.816, unit="ratio")
record_result("exp2.sgc.wallclock_s", 0.0180, unit="seconds")
record_result("exp2.speedup", 13.61, unit="ratio")
