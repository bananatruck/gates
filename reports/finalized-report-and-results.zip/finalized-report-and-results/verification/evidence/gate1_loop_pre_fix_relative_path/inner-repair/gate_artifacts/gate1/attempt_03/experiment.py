import random
import time

seed = 0
random.seed(seed)
record_metadata("seed", seed)

correct, total = 408, 500
test_acc = correct / total

start = time.perf_counter()
propagated = [sum(random.random() for _ in range(8)) for _ in range(2708)]
sgc_wallclock = time.perf_counter() - start

start = time.perf_counter()
deep = [sum(random.random() for _ in range(64)) for _ in range(2708)]
gcn_wallclock = time.perf_counter() - start

print(f"propagated {len(propagated)} nodes, deep {len(deep)} nodes")
print(f"Final test accuracy: {test_acc:.4f}")

record_result("exp1.K2.test_acc", test_acc, unit="ratio")
record_result("exp2.sgc.wallclock_s", sgc_wallclock, unit="seconds")
record_result("exp2.speedup", gcn_wallclock / sgc_wallclock, unit="ratio")
