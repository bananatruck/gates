def train(epochs):
    history = []
    for epoch in range(epochs):
        history.append(1.0 / (epoch - 3))
    return history


record_metadata("seed", 0)
history = train(10)
record_result("exp1.final_loss", history[-1])
