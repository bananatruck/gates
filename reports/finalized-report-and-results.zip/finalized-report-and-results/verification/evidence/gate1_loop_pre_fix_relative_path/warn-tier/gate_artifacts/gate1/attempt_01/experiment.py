import traceback

try:
    ratio = 1 / 0
except ZeroDivisionError:
    traceback.print_exc()

print("RuntimeWarning: invalid value encountered in true_divide")
print("CUDA unavailable, falling back to CPU")

zero = 0.0
record_result("exp1.K2.test_acc", zero * 1.0, unit="ratio")
