record_metadata("seed", 0)
leaked_accuracy = 0.816
record_result("exp1.K2.test_acc", leaked_accuracy * 1.0, unit="ratio")
