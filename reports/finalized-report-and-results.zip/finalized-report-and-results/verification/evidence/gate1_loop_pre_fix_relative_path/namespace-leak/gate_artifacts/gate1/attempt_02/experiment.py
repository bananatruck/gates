record_metadata("seed", 0)
inherited = leaked_accuracy
record_result("exp1.K2.test_acc", inherited * 1.0, unit="ratio")
